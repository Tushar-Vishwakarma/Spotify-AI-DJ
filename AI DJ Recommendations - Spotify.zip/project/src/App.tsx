import React, { useState } from 'react';
import { Play, Pause, SkipForward, Heart, Clock3, Music2, Sparkles } from 'lucide-react';

// Extended recommendation data
const allSongs = [
  {
    id: 1,
    title: "Midnight City",
    artist: "M83",
    genre: "Electronic",
    mood: "Energetic",
    duration: "4:03",
    imageUrl: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=800&auto=format&fit=crop&q=60"
  },
  {
    id: 2,
    title: "Dreams",
    artist: "Fleetwood Mac",
    genre: "Rock",
    mood: "Calm",
    duration: "4:14",
    imageUrl: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&auto=format&fit=crop&q=60"
  },
  {
    id: 3,
    title: "Blinding Lights",
    artist: "The Weeknd",
    genre: "Pop",
    mood: "Energetic",
    duration: "3:20",
    imageUrl: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&auto=format&fit=crop&q=60"
  },
  {
    id: 4,
    title: "Bohemian Rhapsody",
    artist: "Queen",
    genre: "Rock",
    mood: "Epic",
    duration: "5:55",
    imageUrl: "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=800&auto=format&fit=crop&q=60"
  },
  {
    id: 5,
    title: "Chill Vibes",
    artist: "Lo-Fi Beats",
    genre: "Electronic",
    mood: "Calm",
    duration: "3:45",
    imageUrl: "https://images.unsplash.com/photo-1494232410401-ad00d5433cfa?w=800&auto=format&fit=crop&q=60"
  }
];

type Preferences = {
  genre: string;
  mood: string;
};

function App() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [showPreferences, setShowPreferences] = useState(false);
  const [preferences, setPreferences] = useState<Preferences>({ genre: '', mood: '' });
  const [recommendations, setRecommendations] = useState(allSongs.slice(0, 3));
  const [currentSong, setCurrentSong] = useState(recommendations[0]);

  const togglePlay = () => setIsPlaying(!isPlaying);

  const nextSong = () => {
    const currentIndex = recommendations.findIndex(song => song.id === currentSong.id);
    const nextIndex = (currentIndex + 1) % recommendations.length;
    setCurrentSong(recommendations[nextIndex]);
  };

  const generateRecommendations = (prefs: Preferences) => {
    const filtered = allSongs.filter(song => 
      (!prefs.genre || song.genre === prefs.genre) &&
      (!prefs.mood || song.mood === prefs.mood)
    );
    const newRecommendations = filtered.length > 0 ? filtered : allSongs;
    setRecommendations(newRecommendations);
    setCurrentSong(newRecommendations[0]);
    setShowPreferences(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 to-black text-white">
      <div className="container mx-auto px-4 py-8">
        <header className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Music2 className="w-8 h-8" />
              <h1 className="text-2xl font-bold">AI DJ Recommendations</h1>
            </div>
            <button
              onClick={() => setShowPreferences(true)}
              className="flex items-center gap-2 bg-purple-500 hover:bg-purple-600 transition px-4 py-2 rounded-full"
            >
              <Sparkles className="w-4 h-4" />
              Personalize
            </button>
          </div>
          <p className="text-purple-200">Personalized music just for you</p>
        </header>

        {showPreferences && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
            <div className="bg-purple-900 rounded-xl p-6 max-w-md w-full">
              <h2 className="text-xl font-bold mb-4">Your Music Preferences</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Genre</label>
                  <select
                    className="w-full bg-purple-800 rounded-lg p-2 text-white"
                    value={preferences.genre}
                    onChange={(e) => setPreferences({ ...preferences, genre: e.target.value })}
                  >
                    <option value="">Any Genre</option>
                    <option value="Electronic">Electronic</option>
                    <option value="Rock">Rock</option>
                    <option value="Pop">Pop</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Mood</label>
                  <select
                    className="w-full bg-purple-800 rounded-lg p-2 text-white"
                    value={preferences.mood}
                    onChange={(e) => setPreferences({ ...preferences, mood: e.target.value })}
                  >
                    <option value="">Any Mood</option>
                    <option value="Energetic">Energetic</option>
                    <option value="Calm">Calm</option>
                    <option value="Epic">Epic</option>
                  </select>
                </div>
                <div className="flex gap-2 pt-4">
                  <button
                    onClick={() => setShowPreferences(false)}
                    className="flex-1 bg-purple-800 hover:bg-purple-700 transition py-2 rounded-lg"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => generateRecommendations(preferences)}
                    className="flex-1 bg-purple-500 hover:bg-purple-600 transition py-2 rounded-lg"
                  >
                    Generate
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Now Playing */}
        <div className="bg-purple-900/30 rounded-xl p-6 backdrop-blur-lg mb-8">
          <div className="flex flex-col md:flex-row gap-6 items-center">
            <img 
              src={currentSong.imageUrl} 
              alt={currentSong.title}
              className="w-64 h-64 object-cover rounded-lg shadow-2xl"
            />
            <div className="flex-1">
              <h2 className="text-xl font-semibold mb-2">{currentSong.title}</h2>
              <p className="text-purple-200 mb-4">{currentSong.artist}</p>
              
              <div className="flex items-center gap-4 mb-6">
                <button 
                  onClick={togglePlay}
                  className="bg-purple-500 hover:bg-purple-600 transition p-4 rounded-full"
                >
                  {isPlaying ? <Pause /> : <Play />}
                </button>
                <button 
                  onClick={nextSong}
                  className="bg-purple-500/20 hover:bg-purple-500/30 transition p-4 rounded-full"
                >
                  <SkipForward />
                </button>
                <button className="text-purple-200 hover:text-purple-100 transition">
                  <Heart />
                </button>
              </div>

              <div className="flex items-center gap-2 text-sm text-purple-200">
                <Clock3 className="w-4 h-4" />
                <span>{currentSong.duration}</span>
                <span className="mx-2">•</span>
                <span>{currentSong.genre}</span>
                <span className="mx-2">•</span>
                <span>{currentSong.mood}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Up Next */}
        <div>
          <h3 className="text-lg font-semibold mb-4">Up Next</h3>
          <div className="grid gap-4">
            {recommendations.filter(song => song.id !== currentSong.id).map(song => (
              <div 
                key={song.id}
                onClick={() => setCurrentSong(song)}
                className="bg-purple-900/20 hover:bg-purple-900/30 transition rounded-lg p-4 flex items-center gap-4 cursor-pointer"
              >
                <img 
                  src={song.imageUrl} 
                  alt={song.title}
                  className="w-16 h-16 object-cover rounded"
                />
                <div className="flex-1">
                  <h4 className="font-medium">{song.title}</h4>
                  <p className="text-sm text-purple-200">{song.artist}</p>
                </div>
                <div className="text-purple-200 text-sm flex items-center gap-2">
                  <span>{song.duration}</span>
                  <span>•</span>
                  <span>{song.mood}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;